				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
						<!-- the logo in the home page rift valley univerity logo  //class="index_logo" -->
						<img src="images/logo.jpg" class="img-circle" >
						
						</div>	
						<div class="span12">
							<div class="motto">
							<p></p>
							<p></p>												
							</div>											
						</div>							
				  </div>		   							
    </div>	
				