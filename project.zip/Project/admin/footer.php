<div class="setfooter">
		<footer >
           <p align="center"><h4 align="center"> &copy; Rift Valley University <?php
 $date = new DateTime();
 echo $date->format(' Y');
 ?> 
		 

</div>
        <footer>
</div>